
<h1 align="center">Storm Regal Hotel </h1>


### Overview
![Screenshot (130)](https://user-images.githubusercontent.com/62676042/130684751-0d7a6754-b0c0-4e19-9190-5b4e37b4649e.png)
Landing page for a fictional hotel website. All components implemented in html, css, sass and pure javascript. Project completed for fulfillment of HNGi7 internship task
### Built With

<!-- This section should list any major frameworks that you built your project using. Here are a few examples.-->

 ![HTML5](https://img.shields.io/badge/-HTML5-333333?style=flat&logo=HTML5)
  ![CSS](https://img.shields.io/badge/-CSS-333333?style=flat&logo=CSS3&logoColor=1572B6)
  ![JavaScript](https://img.shields.io/badge/-JavaScript-333333?style=flat&logo=javascript)



### Contact🌍
[<img align="left" alt="iyanu-show | Twitter" width="22px" src="https://cdn.jsdelivr.net/npm/simple-icons@v5/icons/twitter.svg" />][twitter]
[<img align="left" alt="iyanu-show | LinkedIn" width="22px"  src="https://cdn.jsdelivr.net/npm/simple-icons@v5/icons/linkedin.svg" />][linkedin]
[<img align="left" alt="iyanu-show" width="22px" src="https://cdn.jsdelivr.net/npm/simple-icons@v5/icons/react.svg" />][website]


<br/>

[website]: https://iyanushowportfolio.netlify.app/
[twitter]: https://twitter.com/the_iyanu
[linkedin]: https://www.linkedin.com/in/iyanuoluwa-sowande-0522/
